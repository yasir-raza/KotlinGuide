package com.kotlin.lesson2

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var binding : com.kotlin.lesson2.databinding.ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btn = findViewById<Button>(R.id.btn_name)
        btn.setOnClickListener{
            NameClick(it)
        }
    }

    private fun NameClick(view : View){
        val editText  = findViewById<EditText>(R.id.name_text)
        val tvText = findViewById<TextView>(R.id.nametv)
        tvText.text = editText.text

        //Hide the keyboard
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(view.windowToken, 0)

    }
}
